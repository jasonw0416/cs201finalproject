
import java.sql.*; // to save space
import java.util.ArrayList;
public class JDBCHandler {
	
	public static void loginQuery (String login, String password) {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/?user=root&password=Wonjun0416@");
			st = conn.createStatement();
			
			String statement = login + password;
			
			rs = st.executeQuery(statement);
			
			
			
			
			
//			rs = st.executeQuery("SELECT lab9.Grades.ClassName, COUNT(*) as Number_of_students	FROM lab9.Grades GROUP BY lab9.Grades.ClassName ORDER BY Number_of_students;");
			
			
			
		 } catch (SQLException sqle) {
			 System.out.println (sqle.getMessage());
		 } finally {
			 try {
				 if (rs != null) {
					 rs.close();
				 }
				 if (st != null) {
					 st.close();
				 }
				 if (conn != null) {
					 conn.close();
				 }
			 } catch (SQLException sqle) {
				 System.out.println(sqle.getMessage());
			 }
		 }
	}
	
	public static ArrayList<Course> searchResultQuery (String statement) {
		try {
		    Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (ClassNotFoundException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		
		ArrayList<Course> courses = new ArrayList<>();
    	
    	Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/?user=root&password=Wonjun0416@");
			st = conn.createStatement();
			rs = st.executeQuery(statement);
			while (rs.next()) {
				String courseID = rs.getString("course_id_string");
				String courseName = rs.getString("course_name_long");
				int startTime = rs.getInt("start_time");
				int endTime = rs.getInt("end_time");
				String professor = rs.getString("name");
				double rating = rs.getDouble("rating");
				String day = "";
				if (rs.getInt("monday") == 1) {
					day += "M";
				}
				if (rs.getInt("tuesday") == 1) {
					day += "T";
				}
				if (rs.getInt("wednesday") == 1) {
					day += "W";
				}
				if (rs.getInt("thursday") == 1) {
					day += "Th";
				}
				if (rs.getInt("friday") == 1) {
					day += "F";
				}
				
				
				if(startTime != 0 && endTime != 0) {
					courses.add(new Course(courseID, courseName, startTime, endTime, professor, rating, day));
				}
			}
			
			rs.close();
		 } catch (SQLException sqle) {
			 System.out.println (sqle.getMessage());
		 } finally {
			 try {
				 if (rs != null) {
					 rs.close();
				 }
				 if (st != null) {
					 st.close();
				 }
				 if (conn != null) {
					 conn.close();
				 }
			 } catch (SQLException sqle) {
				 System.out.println(sqle.getMessage());
			 }
		 }
		
		 return courses;
		 
	}
}
